/**
 * Minified by jsDelivr using Terser v5.39.0.
 * Original file: /npm/moment@2.29.1/moment.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
